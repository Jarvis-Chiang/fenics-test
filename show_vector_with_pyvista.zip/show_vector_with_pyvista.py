'''
Author: Jarvis-Chiang 497694894@qq.com
Date: 2024-08-10 16:58:31
LastEditors: Jarvis-Chiang 497694894@qq.com
LastEditTime: 2024-08-13 21:31:39
FilePath: ./show_vector_with_pyvista.py
Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
'''
import pyvista as pv
import numpy as np


class ShowWithPyvista:
    def __init__(self, filename, **options):
        """
        初始化类并读取向量场数据。

        参数:
        filename : str
            包含向量场数据的文本文件的名称。
        """
        self.vertices = []
        self.faces = []
        self.midpoints = []        
        self.vector_field_midpints = []
        self.vector_field = []
        self.grid = pv.UnstructuredGrid()
        self.plotter = pv.Plotter(**options)
        
        self.__set_plotter(**options)
        self._load_data(filename)
        self._calculate_midpoints()
        self._creat_grid()
        self._add_vector_field_midpoint()
        self._interpolate_vector_field()

    def __set_plotter(self, **options):
        plotter_title = options.get("title", "Plotter Title")
        self.plotter(title=plotter_title )

    def _load_data(self, filename):
        """
        从文件中加载向量场数据。

        参数:
        filename : str
            包含向量场数据的文本文件的名称。
        """
        try:
            with open(filename, 'r') as file:
                content = file.readlines()
        except FileNotFoundError:
            print("File not found. Please input a valid file name!")
            return
        except IOError:
            print("An error occurred while trying to read the file.")
            return

        current_section = None
        for line in content:
            if line.startswith("#"):
                if "Vertices" in line:
                    current_section = "vertices"
                elif "Faces" in line:
                    current_section = "faces"
                elif "Vector field" in line:
                    current_section = "vector_field"
                continue
            if line.strip():
                data = list(map(float, line.strip().split()))
                if current_section == "vertices":
                    self.vertices.append(data)
                elif current_section == "faces":
                    self.faces.append([int(x) for x in data])
                elif current_section == "vector_field":
                    self.vector_field_midpints.append(data)

        # 填充 self.vertices 变量
        self.vertices = np.array(self.vertices)
        if self.vertices.shape[1] == 2:
            self.vertices = np.hstack((self.vertices, np.zeros_like(self.vertices[:, 0]).reshape(-1, 1)))

        # 填充 self.faces 变量
        self.faces = np.array(self.faces, dtype=int)

        # 填充 self.vector_field 变量
        self.vector_field_midpints = np.array(self.vector_field_midpints)
        if self.vector_field_midpints.shape[1] == 2:
            self.vector_field_midpints = np.hstack((self.vector_field_midpints, np.zeros_like(self.vector_field_midpints[:, 0]).reshape(-1, 1)))

        # 填充 self.midpoints 变量
        self._calculate_midpoints()

        # 填充 self.grid 变量
        self._creat_grid()

    def _calculate_midpoints(self):
        """
        计算每个面的中心点，并将其存储在 self.midpoints 中。
        """
        self.midpoints = []
        for face in self.faces:
            face_vertices = self.vertices[face]
            midpoint = np.mean(face_vertices, axis=0)
            self.midpoints.append(midpoint)
        self.midpoints = np.array(self.midpoints)

    def _creat_grid(self):
        cells = grid_faces = np.insert(self.faces, 0, 3, axis=1) 
        celltypes = np.full(len(cells), pv.CellType.TRIANGLE)
        points = self.vertices
        self.grid = pv.UnstructuredGrid(cells, celltypes, points)

    def _add_vector_field_midpoint(self, **options):
        """
        使用 PyVista 显示向量场数据。

        参数:
        **options : dict
            动态选项参数，包括是否显示网格、标题、标量条、标签等。
            可选参数:
            - show_grid: bool, 是否显示网格，默认值为 True。
            - show_title: bool, 是否显示标题，默认值为 False。
            - show_scalar_bar: bool, 是否显示标量条，默认值为 False。
            - show_label: bool, 是否显示标签，默认值为 False。
        """
        show_mesh = options.get('show_mesh', True)
        title = options.get('title', "vector field")
        show_scalar_bar = options.get('show_scalar_bar', False)
        show_label = options.get('show_label', False)
        scalar = options.get('scalar', 0.5)

        # 确保 midpoints 被计算
        if not hasattr(self, 'midpoints') or len(self.midpoints) == 0:
            self._calculate_midpoints()

        # 使用 PyVista 进行可视化
        # 根据用户需求设置可视化选项
 
        # grid_faces = np.insert(self.faces, 0, 3, axis=1) 
        # grid = pv.PolyData(self.vertices, grid_faces)
        # # grid["vectors"] = self.vector_field

        # self.plotter.add_mesh(grid, show_edges=show_mesh, opacity=0.1)

        # 将向量场绘制在 midpoints 上
        # 检测维度是否相同
        if len(self.midpoints) != len(self.vector_field_midpints):
            raise ValueError("The length of midpoints and vector_field must be the same.")
        
        self.plotter.add_arrows(self.midpoints, self.vector_field_midpints[:len(self.midpoints)], mag=scalar)

        # if show_mesh:
        #     self.plotter.add_mesh(grid, show_edges=show_mesh, opacity=0.2)

        # self.plotter.add_title('title')

        # if show_scalar_bar:
        #     plotter.add_scalar_bar("Magnitude")

        # if show_label:
        #     plotter.add_point_labels(self.midpoints, ["Midpoint {}".format(i) for i in range(len(self.midpoints))])

    def _interpolate_vector_field(self, power=2):
        """
        使用逆距离加权插值（IDW）将中心点的向量场插值到网格顶点上。

        参数:
        power : float
            距离的权重指数，默认值为2。
        """
        self.vector_field = np.zeros_like(self.vertices)

        for i, vertex in enumerate(self.vertices):
            # 计算从该顶点到所有中心点的距离
            distances = np.linalg.norm(self.midpoints - vertex, axis=1)
            
            # 防止距离为零，添加一个小值
            distances[distances == 0] = 1e-10
            
            # 计算权重
            weights = 1.0 / distances**power
            
            # 计算加权平均
            weighted_vectors = np.sum(weights[:, np.newaxis] * self.vector_field_midpints, axis=0)
            self.vector_field[i] = weighted_vectors / np.sum(weights)


    def add_streamlines(self, start_points, **options):
        """
        使用 PyVista 显示流线图。

        参数:
        start_points : array-like
            流线图的起始点坐标。
        **options : dict
            动态选项参数，包括流线图的其他设置。
            可选参数:
            - show_grid: bool, 是否显示网格，默认值为 True。
            - show_title: bool, 是否显示标题，默认值为 False。
            - show_scalar_bar: bool, 是否显示标量条，默认值为 False。
        """
        show_grid = options.get('show_grid', True)
        title = options.get('title', "Streamlines")
        show_scalar_bar = options.get('show_scalar_bar', False)

        # 确保 midpoints 被计算
        if not hasattr(self, 'midpoints') or len(self.midpoints) == 0:
            self._calculate_midpoints()

        # 使用 PyVista 进行可视化
        grid_faces = np.insert(self.faces, 0, 3, axis=1) 
        grid = pv.PolyData(self.vertices, grid_faces)

        # 创建一个 PolyData 对象用于流线图
        vector_field = np.array(self.vector_field_midpints)
        grid.point_data['vectors'] = vector_field

        self.plotter.add_mesh(grid, show_edges=show_grid, opacity=0.1)

        # 添加流线图
        streamlines = grid.streamlines(start_points=start_points, vectors='vectors')
        self.plotter.add_mesh(streamlines, color='blue')

        if show_grid:
            self.plotter.add_mesh(grid, show_edges=show_grid, opacity=0.2)

        if show_scalar_bar:
            self.plotter.add_scalar_bar("Magnitude")

        self.plotter.add_title(title)

        self.plotter.show()

    def add_grid(self, **options):
        self.plotter.add_mesh(self.grid)

    def calculate_vector_at_point(p, vertices, vector_field, power=2):
        """
        计算网格内任一点的向量大小和方向。

        参数:
         @p : array-like
            待插值点的坐标。
         @vertices : array-like
            网格顶点的坐标。
         @vector_field : array-like
            网格顶点处的向量场。
         @power : float
            距离的权重指数，默认值为2。

        返回:
         @interpolated_vector : array
            插值点处的向量。
         @magnitude : float
            插值点处的向量大小。
         @direction : array
            插值点处的向量方向（归一化向量）。
        """
        p = np.array(p)
        distances = np.linalg.norm(vertices - p, axis=1)
        distances[distances == 0] = 1e-10  # 防止距离为零，添加一个小值

        # 计算权重
        weights = 1.0 / distances**power

        # 计算加权平均
        interpolated_vector = np.sum(weights[:, np.newaxis] * vector_field, axis=0) / np.sum(weights)

        # 计算向量大小和方向
        magnitude = np.linalg.norm(interpolated_vector)
        direction = interpolated_vector / magnitude if magnitude != 0 else np.zeros(3)

        return interpolated_vector, magnitude, direction
    

    def show(self):
        self.plotter.show()

if __name__ == "__main__":
    sp = ShowWithPyvista("/home/wsl-20/fenicsprojects/让我测试一下/output/theta_vector(adam).txt")
    print("pause!!")